// JavaScript para o site LUM1A.SHOP - Versão Futurística

// Aguarda o carregamento completo da página
document.addEventListener('DOMContentLoaded', function() {
    
    // Smooth scrolling para links internos
    const links = document.querySelectorAll('a[href^="#"]');
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                const headerHeight = document.querySelector('.header').offsetHeight;
                const targetPosition = targetElement.offsetTop - headerHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Efeito de header com blur no scroll
    window.addEventListener('scroll', function() {
        const header = document.querySelector('.header');
        const scrolled = window.pageYOffset;
        
        if (scrolled > 50) {
            header.classList.add('scrolled');
            header.style.backgroundColor = 'rgba(245, 247, 250, 0.95)';
            header.style.backdropFilter = 'blur(20px)';
        } else {
            header.classList.remove('scrolled');
            header.style.backgroundColor = 'var(--background-color)';
            header.style.backdropFilter = 'blur(10px)';
        }
    });

    // Animação de entrada para elementos com Intersection Observer
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in-up');
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Aplica a animação aos cards de oportunidades
    const cards = document.querySelectorAll('.opportunity-card');
    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(50px)';
        card.style.transition = `opacity 0.8s ease ${index * 0.2}s, transform 0.8s ease ${index * 0.2}s`;
        observer.observe(card);
    });

    // Efeito de partículas flutuantes no hero
    createFloatingParticles();

    // Efeito hover aprimorado nos botões
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-3px) scale(1.05)';
            this.style.boxShadow = '0 15px 35px rgba(0, 123, 255, 0.4)';
        });
        
        button.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
            this.style.boxShadow = '0 10px 30px rgba(0, 123, 255, 0.3)';
        });

        // Efeito de ripple ao clicar
        button.addEventListener('click', function(e) {
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            ripple.classList.add('ripple');
            
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });

    // Efeito de cursor personalizado
    createCustomCursor();

    // Animação de digitação para o título principal
    const mainTitle = document.querySelector('.hero h1');
    if (mainTitle && (window.location.pathname.includes('index.html') || window.location.pathname === '/')) {
        animateTypewriter(mainTitle);
    }

    // Efeito de glow nos ícones das oportunidades
    const icons = document.querySelectorAll('.opportunity-icon');
    icons.forEach(icon => {
        icon.addEventListener('mouseenter', function() {
            this.style.boxShadow = '0 0 30px rgba(40, 199, 111, 0.6)';
            this.style.transform = 'scale(1.1) rotate(10deg)';
        });
        
        icon.addEventListener('mouseleave', function() {
            this.style.boxShadow = '0 10px 20px rgba(40, 199, 111, 0.3)';
            this.style.transform = 'scale(1) rotate(0deg)';
        });
    });

    // Tracking de interações
    trackUserInteractions();

    // Console de boas-vindas futurístico
    console.log('%c🚀 LUM1A.SHOP - Portal do Futuro', 'color: #007BFF; font-size: 24px; font-weight: bold; text-shadow: 0 0 10px #007BFF;');
    console.log('%cTecnologia avançada para oportunidades extraordinárias', 'color: #28C76F; font-size: 16px;');
});

// Função para criar partículas flutuantes
function createFloatingParticles() {
    const hero = document.querySelector('.hero');
    if (!hero) return;

    const particlesContainer = document.createElement('div');
    particlesContainer.className = 'particles-container';
    particlesContainer.style.cssText = `
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 1;
    `;
    
    hero.appendChild(particlesContainer);

    for (let i = 0; i < 50; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.cssText = `
            position: absolute;
            width: ${Math.random() * 4 + 1}px;
            height: ${Math.random() * 4 + 1}px;
            background: rgba(${Math.random() > 0.5 ? '0, 123, 255' : '40, 199, 111'}, ${Math.random() * 0.5 + 0.3});
            border-radius: 50%;
            left: ${Math.random() * 100}%;
            top: ${Math.random() * 100}%;
            animation: float ${Math.random() * 10 + 10}s linear infinite;
        `;
        
        particlesContainer.appendChild(particle);
    }
}

// Função para cursor personalizado
function createCustomCursor() {
    const cursor = document.createElement('div');
    cursor.className = 'custom-cursor';
    cursor.style.cssText = `
        position: fixed;
        width: 20px;
        height: 20px;
        background: radial-gradient(circle, rgba(0, 123, 255, 0.8) 0%, transparent 70%);
        border-radius: 50%;
        pointer-events: none;
        z-index: 9999;
        transition: transform 0.1s ease;
        display: none;
    `;
    
    document.body.appendChild(cursor);

    document.addEventListener('mousemove', (e) => {
        cursor.style.left = e.clientX - 10 + 'px';
        cursor.style.top = e.clientY - 10 + 'px';
        cursor.style.display = 'block';
    });

    // Efeito especial ao passar sobre elementos interativos
    const interactiveElements = document.querySelectorAll('a, button, .btn');
    interactiveElements.forEach(element => {
        element.addEventListener('mouseenter', () => {
            cursor.style.transform = 'scale(2)';
            cursor.style.background = 'radial-gradient(circle, rgba(255, 193, 7, 0.8) 0%, transparent 70%)';
        });
        
        element.addEventListener('mouseleave', () => {
            cursor.style.transform = 'scale(1)';
            cursor.style.background = 'radial-gradient(circle, rgba(0, 123, 255, 0.8) 0%, transparent 70%)';
        });
    });
}

// Função de animação de digitação
function animateTypewriter(element) {
    const originalText = element.textContent;
    element.textContent = '';
    element.style.borderRight = '2px solid #007BFF';
    
    let i = 0;
    const typeWriter = function() {
        if (i < originalText.length) {
            element.textContent += originalText.charAt(i);
            i++;
            setTimeout(typeWriter, 100);
        } else {
            // Remove o cursor após terminar
            setTimeout(() => {
                element.style.borderRight = 'none';
            }, 1000);
        }
    };
    
    setTimeout(typeWriter, 1500);
}

// Função para tracking de interações
function trackUserInteractions() {
    const ctaButtons = document.querySelectorAll('a[href^="http"]');
    ctaButtons.forEach(button => {
        button.addEventListener('click', function() {
            const buttonText = this.textContent.trim();
            const currentPage = window.location.pathname;
            
            // Efeito visual de confirmação
            this.style.background = 'var(--secondary-color)';
            this.textContent = '✓ Redirecionando...';
            
            console.log(`🎯 CTA ativado: "${buttonText}" na página: ${currentPage}`);
        });
    });
}

// Função para detectar dispositivos móveis
function isMobile() {
    return window.innerWidth <= 768;
}

// Ajustes para dispositivos móveis
if (isMobile()) {
    // Desabilita efeitos pesados em mobile
    document.body.classList.add('mobile-device');
    
    // Remove cursor personalizado em mobile
    const customCursor = document.querySelector('.custom-cursor');
    if (customCursor) {
        customCursor.style.display = 'none';
    }
}

// Adiciona estilos CSS para os efeitos JavaScript
const style = document.createElement('style');
style.textContent = `
    .ripple {
        position: absolute;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.6);
        transform: scale(0);
        animation: ripple-animation 0.6s linear;
        pointer-events: none;
    }
    
    @keyframes ripple-animation {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
    
    .mobile-device .particles-container {
        display: none;
    }
    
    .mobile-device .custom-cursor {
        display: none !important;
    }
`;
document.head.appendChild(style);

